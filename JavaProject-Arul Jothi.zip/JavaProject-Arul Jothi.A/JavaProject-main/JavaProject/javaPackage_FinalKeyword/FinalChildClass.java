package javaPackage_FinalKeyword;

class FinalChildClass extends FinalClass { }
