package javaPackage_FinalKeyword;

public class FinalMethodClassTest extends FinalMethodClass {
		// Compile time error because we cannot override the final method 
		/*
		* @Override void show() {
		* 
		* System.out.println("This is the final method of FinalMethodEx 
		class"); }
		*/
		}