package javaPackage_HierarchicalInheritance;

public class Four extends One
{
void disp4()
{
System.out.println("Four");
} }