package javaPackage_HierarchicalInheritance;

public class One {

void disp1()
{
System.out.println("One");
} }