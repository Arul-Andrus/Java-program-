package javaPackage_HierarchicalInheritance;

public class Three extends One
{
void disp3()
{
System.out.println("Three");
} }