package javaPackage_MultiLevelInheritance;

public class Four extends Three
{
void disp4()
{
System.out.println("Four");
} }