package javaPackage_MultiLevelInheritance;

public class Three  extends Two
{
void disp3()
{
System.out.println("Three");
} }