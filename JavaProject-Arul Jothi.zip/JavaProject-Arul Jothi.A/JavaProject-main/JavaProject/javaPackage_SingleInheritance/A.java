package javaPackage_SingleInheritance;

public class A{
	public static void main(String[] args) 
	{
	Two obj = new Two();
	obj.disp1();
	obj.disp2();
	} }