package javaPackage_SingleInheritance;

public class One{
	void disp1()
	{
	System.out.println("One");
	} }