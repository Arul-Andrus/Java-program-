package javaPackage_SingleInheritance;

public class Two extends One
{
void disp2()
{
System.out.println("Two");
} }