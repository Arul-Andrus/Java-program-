# JavaProject
This repo contains java  basic codes with examples for core concepts of oops 
